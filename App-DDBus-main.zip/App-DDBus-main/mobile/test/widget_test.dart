import 'package:flutter_test/flutter_test.dart';
import 'package:ddbus/main.dart';
void main() {
  testWidgets('DDBus inicia correctamente', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Flutter Demo Home Page'), findsOneWidget);
  });
}